Details
CIDRIp: IP to allow incoming traffic on DataBase Port

DBInstanceClass:  Database Instance Class; e.g db.m5.large for general purpose or db.r5.large for memory optimized

Engine:  AllowedValues:
      - mariadb
      - mysql
      - oracle-ee
      - oracle-se2
      - oracle-se1
      - oracle-se
      - postgres
      - sqlserver-ee
      - sqlserver-se
      - sqlserver-ex
      - sqlserver-web

DatabaseIdentifier: Database Identifier name for db instance(use lower case and no special character, "-"" allowed)

DatabaseName: Database name of your initial db created

DatabasePort: Database port. If the default -1 is unchanged, a default db port for the specified db type will be used

DBAllocatedStorage: The size of the database (GiB)

MaxAutoscalingStorageLimit: The Max size of the database (GiB) for Autoscaling



Command: aws cloudformation create-stack --stack-name glas-rds-stack --template-body "file://<PATH>" --parameters "file://<PATH>" --tags "file://<PATH>" --profile <profileName> --capabilities CAPABILITY_NAMED_IAM
Command: aws cloudformation create-stack --stack-name glas-stack --template-body "file://<PATH>" --parameters " file://<PATH>" --tags " file://<PATH>" --profile <profileName> --capabilities CAPABILITY_NAMED_IAM

Arpit-----------
Command: aws cloudformation create-stack --stack-name glas-rds-stack --template-body "file://C:\Users\arpsingh\Documents\COVESTRO\#cov-cfn\cov-cfn\GLaS\template.yaml" --parameters " file://C:\Users\arpsingh\Documents\COVESTRO\#cov-cfn\cov-cfn\GLaS\params.json" --profile 996_kkd_glas --capabilities CAPABILITY_NAMED_IAM

aws cloudformation create-stack --stack-name glas-rds-stack-test --template-body "file://C:\Users\acvats\Desktop\open this\Covestro\cov-cfn\glas\template.yaml" --parameters "file://C:\Users\acvats\Desktop\open this\Covestro\cov-cfn\glas\params.json" --tags "file://C:\Users\acvats\Desktop\open this\Covestro\cov-cfn\glas\tag-params.json" --profile 996Devops --capabilities CAPABILITY_NAMED_IAM

Extra Note:

MonitoringInterval
The interval, in seconds, between points when Enhanced Monitoring metrics are collected for the DB instance. To disable collecting Enhanced Monitoring metrics, specify 0. The default is 0.

If MonitoringRoleArn is specified, then you must also set MonitoringInterval to a value other than 0.

Valid Values: 0, 1, 5, 10, 15, 30, 60

Required: No
----------------------------------------------------------------------------------------------------------------------------------------------------------------

PreferredMaintenanceWindow
The weekly time range during which system maintenance can occur, in Universal Coordinated Time (UTC).

Format: ddd:hh24:mi-ddd:hh24:mi

----------------------------------------------------------------------------------------------------------------------------------------------------------------

PreferredBackupWindow
The daily time range during which automated backups are created if automated backups are enabled, using the BackupRetentionPeriod parameter. For more information, see Backup Window in the Amazon RDS User Guide.

Constraints:

Must be in the format hh24:mi-hh24:mi.

Must be in Universal Coordinated Time (UTC).

Must not conflict with the preferred maintenance window.

Must be at least 30 minutes.

----------------------------------------------------------------------------------------------------------------------------------------------------------------

AllocatedStorage
The amount of storage (in gigabytes) to be initially allocated for the database instance.

Note
If any value is set in the Iops parameter, AllocatedStorage must be at least 100 GiB, which corresponds to the minimum Iops value of 1,000. If you increase the Iops value (in 1,000 IOPS increments), then you must also increase the AllocatedStorage value (in 100-GiB increments).

Amazon Aurora

Not applicable. Aurora cluster volumes automatically grow as the amount of data in your database increases, though you are only charged for the space that you use in an Aurora cluster volume.

MySQL

Constraints to the amount of storage for each storage type are the following:

General Purpose (SSD) storage (gp2): Must be an integer from 20 to 65536.

Provisioned IOPS storage (io1): Must be an integer from 100 to 65536.

Magnetic storage (standard): Must be an integer from 5 to 3072.

MariaDB

Constraints to the amount of storage for each storage type are the following:

General Purpose (SSD) storage (gp2): Must be an integer from 20 to 65536.

Provisioned IOPS storage (io1): Must be an integer from 100 to 65536.

Magnetic storage (standard): Must be an integer from 5 to 3072.

PostgreSQL

Constraints to the amount of storage for each storage type are the following:

General Purpose (SSD) storage (gp2): Must be an integer from 20 to 65536.

Provisioned IOPS storage (io1): Must be an integer from 100 to 65536.

Magnetic storage (standard): Must be an integer from 5 to 3072.

Oracle

Constraints to the amount of storage for each storage type are the following:

General Purpose (SSD) storage (gp2): Must be an integer from 20 to 65536.

Provisioned IOPS storage (io1): Must be an integer from 100 to 65536.

Magnetic storage (standard): Must be an integer from 10 to 3072.

SQL Server

Constraints to the amount of storage for each storage type are the following:

General Purpose (SSD) storage (gp2):

Enterprise and Standard editions: Must be an integer from 20 to 16384.

Web and Express editions: Must be an integer from 20 to 16384.

Provisioned IOPS storage (io1):

Enterprise and Standard editions: Must be an integer from 20 to 16384.

Web and Express editions: Must be an integer from 20 to 16384.

Magnetic storage (standard):

Enterprise and Standard editions: Must be an integer from 20 to 1024.

Web and Express editions: Must be an integer from 20 to 1024.

----------------------------------------------------------------------------------------------------------------------------------------------------------------

BackupRetentionPeriod
The number of days for which automated backups are retained. Setting this parameter to a positive number enables backups. Setting this parameter to 0 disables automated backups.

Amazon Aurora

Not applicable. The retention period for automated backups is managed by the DB cluster.

Default: 1

Constraints:

Must be a value from 0 to 35

Can't be set to 0 if the DB instance is a source to read replicas
